﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SQS_OrderModule.Models;
using SQS_OrderModule.Services;

namespace SQS_OrderModule.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private ISqsService sqsService;
        private string queueName;
        private string accountId;
        private string serviceUrl;

        public HomeController(ILogger<HomeController> logger,IConfiguration configuration, ISqsService sqsService)
        {
            _logger = logger;
            this.sqsService = sqsService;
            serviceUrl = configuration.GetSection("SQS")["ServiceUrl"];
            accountId = configuration.GetSection("SQS")["AccountId"];
            queueName = configuration.GetSection("SQS")["Queue"];
            sqsService.InitializeSQSClient(serviceUrl, accountId);
            sqsService.CreateQueueAsync(queueName, 45).GetAwaiter().GetResult();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(string message, string messageGrpId, string deduplicationId)
        {
            if (!string.IsNullOrEmpty(messageGrpId) && !string.IsNullOrEmpty(deduplicationId))
            {
                await sqsService.SendFifoQueueMessageAsync(queueName, messageGrpId, deduplicationId, message);
            }
            else
            {
                await sqsService.SendStandardQueueMessageAsync(queueName, message);
            }
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> GetMessages()
        {
            //read messages using long polling
            var messages = await sqsService.ReceiveMessagesAsync(queueName,noOfMessages:5, longPollingWaitTime:20);
            ViewBag.Messages = messages;
            return View("Index");
        }

        [HttpPost]
        public async Task<ActionResult> DeleteMessage(string receiptHandle)
        {
            var result=await sqsService.DeleteMessageAsync(queueName, receiptHandle);
            return View("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
