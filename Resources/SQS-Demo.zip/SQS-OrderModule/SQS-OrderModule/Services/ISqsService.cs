﻿using Amazon.SQS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SQS_OrderModule.Services
{
    public interface ISqsService
    {
        void InitializeSQSClient(string serviceUrl, string awsAccountId);

        Task<bool> CreateQueueAsync(string queueName, int visibilityTimeout);

        Task<string> SendFifoQueueMessageAsync(string queueName, string msgGroupId, string deduplicationId, string messageBody);

        Task<string> SendStandardQueueMessageAsync(string queueName, string messageBody);

        Task SendMessageBatchAsync(string queueName, List<string> messages);

        Task<List<Message>> ReceiveMessagesAsync(string queueName, int noOfMessages = 1, int longPollingWaitTime = 0, int visibilityTimeoutInSecs = 30);

        Task<bool> DeleteMessageAsync(string queueName, string receiptHandle);
    }
}
