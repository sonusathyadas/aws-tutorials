﻿using Amazon.Extensions.NETCore.Setup;
using Amazon.SQS;
using Amazon.SQS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SQS_OrderModule.Services
{
    public class SqsService:ISqsService
    {
        private AmazonSQSConfig sqsConfig;
        private AmazonSQSClient sqsClient;
        private string accountId;

        public void InitializeSQSClient(string serviceUrl, string awsAccountId)
        {
            sqsConfig = new AmazonSQSConfig();
            sqsConfig.ServiceURL = serviceUrl;
            sqsClient = new AmazonSQSClient(sqsConfig);
            accountId = awsAccountId;
        }

        public async Task<bool> CreateQueueAsync(string queueName, int visibilityTimeout)
        {
            if (sqsClient == null)
                throw new Exception("SQSClient is not initilized yet");
            try
            {
                var request = new CreateQueueRequest();
                request.QueueName = queueName;                
                var attrs = new Dictionary<string, string>();
                attrs.Add(QueueAttributeName.VisibilityTimeout, visibilityTimeout.ToString());
                request.Attributes = attrs;
                if (queueName.EndsWith(".fifo"))
                {
                    request.Attributes.Add("FifoQueue", "true");
                }

                var createQueueResponse = await sqsClient.CreateQueueAsync(request);
                return createQueueResponse.HttpStatusCode == System.Net.HttpStatusCode.Created ? true : false;
            }catch(Exception ex)
            {
                Console.WriteLine("Error:"+ ex.Message);
                return false;
            }
        }

        public async Task<string> SendFifoQueueMessageAsync(string queueName, string msgGroupId, string deduplicationId, string messageBody)
        {
            if (sqsClient == null)
                throw new Exception("SQSClient is not initilized yet");

            var queueUrl = await GetQueueUrlAsync(queueName, accountId);
            var request = new SendMessageRequest();
            request.QueueUrl = queueUrl;
            request.MessageBody = messageBody;
            request.MessageGroupId = msgGroupId;
            request.MessageDeduplicationId = deduplicationId;
            var response = await sqsClient.SendMessageAsync(request);
            return response.MessageId;
        }

        public async Task<string> SendStandardQueueMessageAsync(string queueName, string messageBody)
        {
            if (sqsClient == null)
                throw new Exception("SQSClient is not initilized yet");

            var queueUrl = await GetQueueUrlAsync(queueName, accountId);
            var sendMessageRequest = new SendMessageRequest();
            sendMessageRequest.QueueUrl = queueUrl;
            sendMessageRequest.MessageBody = messageBody;
            var sendMessageResponse = await sqsClient.SendMessageAsync(sendMessageRequest);
            return sendMessageResponse.MessageId;
        }

        public async Task SendMessageBatchAsync(string queueName, List<string> messages)
        {
            if (sqsClient == null)
                throw new Exception("SQSClient is not initilized yet");

            var queueUrl = await GetQueueUrlAsync(queueName, accountId);

            List<SendMessageBatchRequestEntry> messageBatch = 
                messages.Select(m => new SendMessageBatchRequestEntry(Guid.NewGuid().ToString(), m))
                .ToList();

            var request = new SendMessageBatchRequest()
            {
                Entries = messageBatch,
                QueueUrl = queueUrl
            };
            SendMessageBatchResponse response = await sqsClient.SendMessageBatchAsync(request);
            Console.WriteLine("Messages successfully sent:");
            foreach (var success in response.Successful)
            {
                Console.WriteLine("    Message id : {0}", success.MessageId);
            }

            Console.WriteLine("Messages failed to send:");
            foreach (var failed in response.Failed)
            {
                Console.WriteLine("    Message id : {0}", failed.Id);
                Console.WriteLine("    Sender's fault? : {0}", failed.SenderFault);
            }
        }

        public async Task<List<Message>> ReceiveMessagesAsync(string queueName, int noOfMessages=1, int longPollingWaitTime=0, int visibilityTimeoutInSecs=30)
        {
            if (sqsClient == null)
                throw new Exception("SQSClient is not initilized yet");
            if (noOfMessages > 10)
                throw new Exception("Maximum 10 messages can be retrieved");
            if(longPollingWaitTime > 20)
            {
                throw new Exception("Long polling waiting time can be maximum upto 20 seconds");
            }
            var queueUrl = await GetQueueUrlAsync(queueName, accountId);
            var receiveMessageRequest = new ReceiveMessageRequest()
            {
                QueueUrl = queueUrl,
                MaxNumberOfMessages = noOfMessages,
                VisibilityTimeout = visibilityTimeoutInSecs,
                WaitTimeSeconds = longPollingWaitTime //For long polling, if set to 0 it does short polling
            };            
            var response = await sqsClient.ReceiveMessageAsync(receiveMessageRequest);
            return response.Messages;
        }

        public async Task<bool> DeleteMessageAsync(string queueName, string receiptHandle)
        {
            if (sqsClient == null)
                throw new Exception("SQSClient is not initilized yet");
            try
            {
                var queueUrl = await GetQueueUrlAsync(queueName, accountId);
                var request = new DeleteMessageRequest();
                request.QueueUrl = queueUrl;
                request.ReceiptHandle = receiptHandle;
                var response = await sqsClient.DeleteMessageAsync(request);
                return response.HttpStatusCode == System.Net.HttpStatusCode.OK ? true : false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw ex;
            }
        }

        private async Task<string> GetQueueUrlAsync(string queueName, string awsAccountId)
        {
            var request = new GetQueueUrlRequest()
            {
                QueueName=queueName,
                QueueOwnerAWSAccountId=awsAccountId
            };
            var response = await sqsClient.GetQueueUrlAsync(request);
            return response.QueueUrl;
        }
    }
}
