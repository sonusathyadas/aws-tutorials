﻿using System;
using System.Collections.Generic;
using System.Text;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.DataModel;
using Amazon.Auth;
using Amazon;
using Amazon.Runtime;
using System.Threading.Tasks;
using System.Threading;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace DynamoDB_Demos
{
    public class DynamoDbHelper<T> where T:class
    {
        private AmazonDynamoDBClient client;
        private DynamoDBContext context=null;

        public void CreateClientForLocalDb()
        {
            AmazonDynamoDBConfig config = new AmazonDynamoDBConfig()
            {
                ServiceURL = "http://localhost:8000"
            };
            try
            {
                client = new AmazonDynamoDBClient(config);
                context = new DynamoDBContext(client);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw ex;
            }
        }

        public void CreateClientForDynamoDb(string accessKeyId, string accessKey, RegionEndpoint region)
        {
            try
            {
                client = new AmazonDynamoDBClient(accessKeyId, accessKey, region);
                context = new DynamoDBContext(client);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw ex;
            }
        }

        public async Task<bool> CreateTableIfNotExists(string tableName, string primaryKey,string sortKey="",int readCapacity=5, int writeCapacity=5)
        {
            var tableResponse = await client.ListTablesAsync();
            if (tableResponse.TableNames.Contains(tableName))
            {
                Console.WriteLine($"Table with the name {tableName} already exists");
                return false;
            }
            else
            {
                try
                {
                    var keySchemas = new List<KeySchemaElement>();
                    keySchemas.Add(new KeySchemaElement
                    {
                        AttributeName = primaryKey,
                        KeyType = KeyType.HASH
                    });
                    if (!string.IsNullOrEmpty(sortKey))
                    {
                        keySchemas.Add(new KeySchemaElement
                        {
                            AttributeName = sortKey,
                            KeyType = KeyType.RANGE
                        });
                    }
                    var attributeDefinitions = new List<AttributeDefinition>();
                    attributeDefinitions.Add(new AttributeDefinition
                    {
                        AttributeName = primaryKey,
                        AttributeType = ScalarAttributeType.S
                    });
                    if (!string.IsNullOrEmpty(sortKey))
                    {
                        attributeDefinitions.Add(new AttributeDefinition
                        {
                            AttributeName = sortKey,
                            AttributeType = ScalarAttributeType.S
                        });
                    }
                    
                    CreateTableRequest request = new CreateTableRequest()
                    {
                        TableName = tableName,                        
                        ProvisionedThroughput = new ProvisionedThroughput()
                        {
                            ReadCapacityUnits = readCapacity,
                            WriteCapacityUnits = writeCapacity
                        },
                        KeySchema = keySchemas,
                        AttributeDefinitions = attributeDefinitions
                    };
                    var response = await client.CreateTableAsync(request);
                    bool isTableAvailable = false;
                    DescribeTableResponse tableStatus=null;
                    while (!isTableAvailable)
                    {
                        Thread.Sleep(5000);
                        tableStatus = await client.DescribeTableAsync(tableName);
                        isTableAvailable = tableStatus.Table.TableStatus == "ACTIVE";
                    }
                    Console.WriteLine("Table created successfully");
                    var data= JsonConvert.SerializeObject(tableStatus.Table, Formatting.Indented);
                    Console.WriteLine(data);
                    return true;
                }catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public async Task AddItemAsync(T document )
        {
            try
            {
                await context.SaveAsync<T>(document);
                Console.WriteLine("Item added to table successfully");
            }catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw ex;
            }
        }

        public async Task<List<T>> ReadItemsAsync(string propertyName, object propertyValue)
        {
            List<ScanCondition> conditions = new List<ScanCondition>();
            conditions.Add(new ScanCondition(propertyName, ScanOperator.Equal, propertyValue));
            var allDocs = await context.ScanAsync<T>(conditions).GetRemainingAsync();
            return allDocs;
        }

        public async Task<List<Document>> QueryTableAsync(QueryOperationConfig queryConfig)
        {
            var table = context.GetTargetTable<T>();
            
            var search = table.Query(queryConfig);
            List<Document> resultDocs = new List<Document>();
            do
            {
                try
                {                 
                    resultDocs.AddRange(await search.GetNextSetAsync());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(" FAILED to get the next batch of movies from Search! Reason:\n " + ex.Message);
                }
                
            } while (!search.IsDone);
            return resultDocs;
        }

        
        #region Private methods
        private Table GetTargetTable<TType>()
        {
            return context.GetTargetTable<TType>();
        }
        #endregion
    }
}
