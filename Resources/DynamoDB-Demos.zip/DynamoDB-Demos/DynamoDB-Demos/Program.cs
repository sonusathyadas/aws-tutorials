﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Threading.Tasks;
using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Newtonsoft.Json;

namespace DynamoDB_Demos
{
    class Program
    {
        const string ACCESS_ID = "--ACCESS ID HERE--";
        const string ACCESS_KEY = "--ACCESS KEY HERE--";

        static async Task Main(string[] args)
        {
            DynamoDbHelper<Employee> dbHelper = new DynamoDbHelper<Employee>();

            dbHelper.CreateClientForDynamoDb(ACCESS_ID, ACCESS_KEY, RegionEndpoint.APSouth1);

            var tableName = nameof(Employee);

            await dbHelper.CreateTableIfNotExists(tableName,primaryKey: "Department", sortKey:"Id");

            //Employee emp = new Employee
            //{
            //    Department="IT",
            //    Id="E126",
            //    Name="Mahendra",
            //    Salary=13000,
            //    Email="mahendra@gmail.com"
            //};
            //await dbHelper.AddItemAsync(emp);
            //Employee emp2 = new Employee
            //{
            //    Department = "Sales",
            //    Id = "E103",
            //    Name = "Vijay",
            //    Salary = 23000,
            //    Email = "vijay@gmail.com"
            //};
            //await dbHelper.AddItemAsync(emp2);

            //var res = await dbHelper.ReadItemsAsync("Department", "IT");
            //var data = JsonConvert.SerializeObject(res, Formatting.Indented);
            //Console.WriteLine(data);

            //Read multiple docs using complex query
            //QueryOperationConfig config = new QueryOperationConfig();
            //config.Filter = new QueryFilter();
            //config.Filter.AddCondition("Department", QueryOperator.Equal, new DynamoDBEntry[] { "IT" });
            //config.Filter.AddCondition("Salary", QueryOperator.Between, new DynamoDBEntry[] { 15000, 25000 });
            //config.AttributesToGet = new List<string> { "Id", "Name", "Email" };
            //config.Select = SelectValues.SpecificAttributes;
            //var docs = await dbHelper.QueryTableAsync(config);
            //var docList = JsonConvert.SerializeObject(docs, Formatting.Indented);
            //Console.WriteLine(docList);
        }
       
    }
}
