﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DynamoDB_Demos
{
    public class Employee
    {
        //Partition Key
        public string Department { get; set; }

        //Sort Key
        public string Id { get; set; }

        public string Name { get; set; }

        public double Salary { get; set; }

        public string Email { get; set; }

    }
}
