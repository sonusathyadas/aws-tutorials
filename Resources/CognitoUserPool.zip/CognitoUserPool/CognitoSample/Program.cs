﻿using Amazon;
using Amazon.CognitoIdentity;
using Amazon.CognitoIdentityProvider;
using Amazon.CognitoIdentityProvider.Model;
using Amazon.Extensions.CognitoAuthentication;
using Amazon.Runtime;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CognitoSample
{
    class Program
    {
        static string poolId = "us-east-1_wKmQYgajJ";
        static string clientId = "1qjtl6m86282togsfph1udtskg";

        private static async Task SignUpAsync()
        {
            Console.WriteLine("Enter username:");
            var username = Console.ReadLine();
            Console.WriteLine("Enter password:");
            var password = Console.ReadLine();
            Console.WriteLine("Enter email:");
            var email = Console.ReadLine();

            AmazonCognitoIdentityProviderClient provider =
                new AmazonCognitoIdentityProviderClient(new AnonymousAWSCredentials(), RegionEndpoint.USEast1);

            SignUpRequest signUpRequest = new SignUpRequest()
            {
                ClientId= clientId,
                Username = username,
                Password = password
            };
            List<AttributeType> attributes = new List<AttributeType>()
            {
                new AttributeType(){ Name="email", Value=email}
            };
            signUpRequest.UserAttributes = attributes;
            try
            {
                SignUpResponse response = await provider.SignUpAsync(signUpRequest);
                Console.WriteLine("User created successfully");
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error:" + ex.Message);
            }
            

        }

        private static async Task SignInAsync()
        {
            Console.WriteLine("Enter username:");
            var username = Console.ReadLine();
            Console.WriteLine("Enter password:");
            var password = Console.ReadLine();

            AmazonCognitoIdentityProviderClient provider =
               new AmazonCognitoIdentityProviderClient(new AnonymousAWSCredentials(), RegionEndpoint.USEast1);

            CognitoUserPool userPool = new CognitoUserPool(poolId, clientId, provider);
            CognitoUser user = new CognitoUser(username, clientId, userPool, provider);

            InitiateSrpAuthRequest authReqeust = new InitiateSrpAuthRequest()
            {
                Password= password
            };

            try
            {
                var authResponse = await user.StartWithSrpAuthAsync(authReqeust);
                
                if (authResponse.ChallengeName == "NEW_PASSWORD_REQUIRED")
                {
                    Console.WriteLine("User is logging in for first time, Need to change the password");
                    Console.WriteLine("Enter the new password:");
                    var newPassword = Console.ReadLine();
                    Dictionary<string, string> challengeResponses = new Dictionary<string, string>()
                    {
                        { "USERNAME", username },
                        {"NEW_PASSWORD", newPassword }
                    };
                    RespondToAuthChallengeRequest challengeRequest = new RespondToAuthChallengeRequest()
                    {
                        ChallengeName= "NEW_PASSWORD_REQUIRED",
                        ClientId=clientId,
                        ChallengeResponses = challengeResponses,
                        Session = authResponse.SessionID
                    };
                    var authChallengeResponse=await provider.RespondToAuthChallengeAsync(challengeRequest);
                    if (authChallengeResponse.HttpStatusCode == System.Net.HttpStatusCode.OK) { 
                        Console.WriteLine("Password updated successfully");
                    }
                    else
                    {
                        Console.WriteLine("Failed to update password");
                    }
                }
                else
                {
                    Console.WriteLine("Login successful\n");
                    Console.WriteLine($"Access Token:{authResponse.AuthenticationResult.AccessToken}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.WriteLine($"Id Token:{authResponse.AuthenticationResult.IdToken}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.WriteLine($"Refresh Token:{authResponse.AuthenticationResult.RefreshToken}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    GetUserRequest getUserRequest = new GetUserRequest();
                    getUserRequest.AccessToken = authResponse.AuthenticationResult.AccessToken;
                    GetUserResponse getUserResponse = await provider.GetUserAsync(getUserRequest);
                    Console.WriteLine($"User name:{getUserResponse.Username}\n");
                    Console.WriteLine("------------------------------------------------------------------------");
                    foreach (var attr in getUserResponse.UserAttributes)
                    {
                        Console.WriteLine($"{attr.Name} : {attr.Value}");
                        Console.WriteLine("------------------------------------------------------------------------");
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Login failed, " + ex.Message);
            }

        }

        
        static async Task Main(string[] args)
        {
            //await SignUpAsync();
            await SignInAsync();
            Console.ReadKey();
        }
    }
}
