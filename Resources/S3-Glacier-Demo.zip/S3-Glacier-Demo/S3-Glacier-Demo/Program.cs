﻿
using System;
using System.Threading.Tasks;
using Amazon.Glacier;
using Amazon.Glacier.Transfer;
using Amazon.Runtime;

namespace S3_Glacier_Demo
{
    class Program
    {
        static string vault = "sample-vault";
        static string archiveToUpload = @"C:\Users\sonus\Desktop\requirements.txt";
        static string downloadFilePath = @"C:\Users\sonus\Desktop\req.txt";
        static int currentPercentage = -1;

        static async Task Main(string[] args)
        {
            var archiveId = await UploadAsync(vault, archiveToUpload);
            Console.WriteLine("To continue, press Enter");
            await DownloadAsync(vault, archiveId, downloadFilePath);
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }


        public static async Task<string> UploadAsync(string vaultName, string archivePath)
        {
            try
            {
                var manager = new ArchiveTransferManager(Amazon.RegionEndpoint.APSouth1);
                // Upload an archive.                
                string archiveId = (await manager.UploadAsync(vaultName, "upload archive test", archivePath)).ArchiveId;
                Console.WriteLine("Archive ID: (Copy and save this ID for use in other examples.) : {0}", archiveId);
                return archiveId;
            }
            catch (AmazonGlacierException e) { Console.WriteLine(e.Message); }
            catch (AmazonServiceException e) { Console.WriteLine(e.Message); }
            catch (Exception e) { Console.WriteLine(e.Message); }
            return null;
        }

        public static async Task DownloadAsync(string vaultName, string archiveId, string downloadPath)
        {
            try
            {
                var manager = new ArchiveTransferManager(Amazon.RegionEndpoint.APSouth1);

                var options = new DownloadOptions();
                options.StreamTransferProgress += Progress;
                // Download an archive.
                Console.WriteLine("Intiating the archive retrieval job and then polling SQS queue for the archive to be available.");
                Console.WriteLine("Once the archive is available, downloading will begin.");
                await manager.DownloadAsync(vaultName, archiveId, downloadPath, options);
            }
            catch (AmazonGlacierException e) { Console.WriteLine(e.Message); }
            catch (AmazonServiceException e) { Console.WriteLine(e.Message); }
            catch (Exception e) { Console.WriteLine(e.Message); }
        }

        static void Progress(object sender, StreamTransferProgressArgs args)
        {
            if (args.PercentDone != currentPercentage)
            {
                currentPercentage = args.PercentDone;
                Console.WriteLine("Downloaded {0}%", args.PercentDone);
            }
        }
    }
}
