﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon;
using Amazon.CognitoIdentityProvider;
using Amazon.CognitoIdentityProvider.Model;
using Amazon.Runtime;

namespace ServerSideUserPoolAuth
{
    class Program
    {
        static string _secretAccessKey = "--SECRET ACCESS KEY HERE --";
        static string _secretAccessKeyId = "-- ACCESS KEY ID HERE --";
        static string _clientId = "--APP CLIENT ID HERE--";
        static string _userPoolId = "--USER POOL ID HERE--";
        static string _username = "--USER POOL USER USERNAME HERE--";
        static string _password = "--USER POOL USER PASSWORD HERE--";

        static async Task Main(string[] args)
        {
            AWSCredentials credentials = new BasicAWSCredentials(_secretAccessKeyId, _secretAccessKey);
            AmazonCognitoIdentityProviderClient provider 
                = new AmazonCognitoIdentityProviderClient(credentials, RegionEndpoint.USEast1);

            Dictionary<string, string> authParams = new Dictionary<string, string>()
            {
                { "USERNAME", _username },
                { "PASSWORD", _password }
            };
            AdminInitiateAuthRequest authRequest = new AdminInitiateAuthRequest()
            {
                AuthFlow = AuthFlowType.ADMIN_NO_SRP_AUTH,
                ClientId = _clientId,
                UserPoolId = _userPoolId,
                AuthParameters = authParams               
            };

            AdminInitiateAuthResponse response = await provider.AdminInitiateAuthAsync(authRequest);
            Console.WriteLine($"Id token:{response.AuthenticationResult.IdToken}");
            Console.WriteLine("---------------------------------------------------------------------------");
            Console.WriteLine($"Access Token:{response.AuthenticationResult.AccessToken}");
            Console.WriteLine("---------------------------------------------------------------------------");
            Console.WriteLine($"Refresh Token:{response.AuthenticationResult.RefreshToken}");
        }
    }
}
