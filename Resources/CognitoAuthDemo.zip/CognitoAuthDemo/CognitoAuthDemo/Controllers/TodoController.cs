﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CognitoAuthDemo.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CognitoAuthDemo.Controllers
{
    [Route("api/todos")]
    [ApiController]
    [Authorize]
    public class TodoController : ControllerBase
    {
        //User IdToken to access the apis
        [HttpGet]
        public ActionResult<List<Todo>> GetTodos()
        {
            return new List<Todo>()
            {
                new Todo{ Id=1, Title="Buy vegs", Completed= false},
                new Todo{ Id=2, Title = "Attend meeting", Completed = true}
            };
        }
    }
}
