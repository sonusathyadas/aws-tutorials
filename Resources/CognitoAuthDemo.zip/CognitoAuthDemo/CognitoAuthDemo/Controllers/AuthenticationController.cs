﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon;
using Amazon.CognitoIdentityProvider;
using Amazon.CognitoIdentityProvider.Model;
using Amazon.Extensions.CognitoAuthentication;
using Amazon.Runtime;
using CognitoAuthDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace CognitoAuthDemo.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private string _clientId;
        private string _userPoolId;
        private readonly RegionEndpoint _region = RegionEndpoint.USEast1;

        public AuthenticationController(IConfiguration config)
        {
            _clientId = config.GetSection("AWS")["ClientId"];
            _userPoolId = config.GetSection("AWS")["UserPoolId"];
        }

        [HttpPost("register")]
        public async Task<ActionResult<User>> Register(User user)
        {
            var provider = new AmazonCognitoIdentityProviderClient(_region);

            var request = new SignUpRequest
            {
                ClientId = _clientId,
                Password = user.Password,
                Username = user.Username
            };

            var emailAttribute = new AttributeType
            {
                Name = "email",
                Value = user.Email
            };
            request.UserAttributes.Add(emailAttribute);
            var response = await provider.SignUpAsync(request);
            return Created("",user);
        }

        [HttpPost("signin")]
        public async Task<ActionResult<AuthenticationResultType>> SignIn(User user)
        {
            var provider = new AmazonCognitoIdentityProviderClient(new AnonymousAWSCredentials(), _region);

            CognitoUserPool userPool = new CognitoUserPool(_userPoolId, _clientId, provider);
            CognitoUser cognitoUser = new CognitoUser(user.Username, _clientId, userPool, provider);

            var request = new InitiateSrpAuthRequest()
            {
                Password = user.Password
            };
            try
            {
                var response = await cognitoUser.StartWithSrpAuthAsync(request);
                if (response.ChallengeName == null)
                {
                    return Ok(response.AuthenticationResult);
                }
                else
                {
                    return Unauthorized("Invalid username or password");
                }
            }catch(Exception ex)
            {
                return Unauthorized(ex.Message);
            }
        }
    }
}
